package com.tiffino.orderservice.enumss;

public enum MealType {

    BREAKFAST,
    LUNCH,
    DINNER
}
