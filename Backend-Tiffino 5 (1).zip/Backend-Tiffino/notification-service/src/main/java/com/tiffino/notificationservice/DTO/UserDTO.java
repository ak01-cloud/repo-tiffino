package com.tiffino.notificationservice.DTO;

import lombok.Data;

@Data
public class UserDTO {
    private String username;
    private String userEmail;
    private String password;
}