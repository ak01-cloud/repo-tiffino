package com.tiffino.notificationservice.Entity;

public enum NotificationType {
    EMAIL, EMAIL_SUBSCRIPTION, SMS, PUSH
}
