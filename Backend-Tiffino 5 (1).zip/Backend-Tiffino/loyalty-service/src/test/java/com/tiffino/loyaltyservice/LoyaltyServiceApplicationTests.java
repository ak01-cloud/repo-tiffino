package com.tiffino.loyaltyservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoyaltyServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
