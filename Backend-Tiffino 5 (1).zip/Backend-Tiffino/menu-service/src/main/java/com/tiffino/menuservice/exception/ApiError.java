package com.tiffino.menuservice.exception;

public class ApiError {
}
