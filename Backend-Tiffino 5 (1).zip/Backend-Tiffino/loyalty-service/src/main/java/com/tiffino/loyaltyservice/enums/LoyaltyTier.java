package com.tiffino.loyaltyservice.enums;

public enum LoyaltyTier {
    BRONZE, SILVER, GOLD, PLATINUM
}