package com.tiffino.notificationservice.Entity;

public enum NotificationStatusType {
    ORDER_ON_THE_WAY,
    ORDER_CANCELLED,
    ORDER_DELIVERED
}
