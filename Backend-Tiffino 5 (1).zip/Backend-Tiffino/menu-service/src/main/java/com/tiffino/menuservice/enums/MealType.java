package com.tiffino.menuservice.enums;

public enum MealType {
    VEG,
    NON_VEG
}
