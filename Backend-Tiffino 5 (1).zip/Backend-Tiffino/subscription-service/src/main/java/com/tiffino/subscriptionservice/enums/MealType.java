package com.tiffino.subscriptionservice.enums;

public enum MealType {
    BREAKFAST, DINNER, LUNCH, SNACK

}