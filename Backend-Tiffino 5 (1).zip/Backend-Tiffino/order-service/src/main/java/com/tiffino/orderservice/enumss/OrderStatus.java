package com.tiffino.orderservice.enumss;

public enum OrderStatus {

    PENDING,
    CONFIRMED,
    PREPARING,
    EN_ROUTE,
    DELIVERED,
    CANCELLED


}
