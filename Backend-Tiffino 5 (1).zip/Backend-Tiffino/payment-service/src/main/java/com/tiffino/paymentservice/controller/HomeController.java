//package com.tiffino.paymentservice.controller;
//
//import lombok.RequiredArgsConstructor;
//import org.springframework.web.bind.annotation.*;
//
//
//@RestController
//@RequestMapping("/Welcome")
//@RequiredArgsConstructor
//public class HomeController {
//
//    @GetMapping("/run")
//    public String Welcome() {
//        return "Welcome to Payment Service";
//    }
//}