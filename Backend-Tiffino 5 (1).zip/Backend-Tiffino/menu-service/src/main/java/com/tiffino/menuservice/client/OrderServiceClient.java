package com.tiffino.menuservice.client;

public class OrderServiceClient {
}
