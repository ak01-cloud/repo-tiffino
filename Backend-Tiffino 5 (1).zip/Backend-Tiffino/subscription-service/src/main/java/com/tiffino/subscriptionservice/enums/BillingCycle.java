package com.tiffino.subscriptionservice.enums;

public enum BillingCycle {
    DAILY, WEEKLY, BIWEEKLY, MONTHLY, QUARTERLY, YEARLY
}