package com.tiffino.loyaltyservice.enums;

public enum RewardStatus {
    PENDING,
    APPROVED,
    REDEEMED,
    EXPIRED,
    REFUND
}