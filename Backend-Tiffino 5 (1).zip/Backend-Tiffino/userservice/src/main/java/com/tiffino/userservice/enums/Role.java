package com.tiffino.userservice.enums;

public enum Role {


    ADMIN,
    SUBADMIN,
    CUSTOMER,
    DELIVERY_PARTNER

}
