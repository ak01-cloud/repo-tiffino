package com.tiffino.userservice.enums;

public enum AllergenPreferences {

    DairyFree,
    NutFree,
    GlutenFree
}
