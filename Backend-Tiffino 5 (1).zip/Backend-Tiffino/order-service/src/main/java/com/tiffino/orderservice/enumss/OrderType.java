package com.tiffino.orderservice.enumss;

public enum OrderType {
    ONE_TIME,
    SUBSCRIPTION

}
