package com.tiffino.userservice.enums;

public enum DietaryPreferences {

    Vegetarian,
    Vegan,
    Keto,
    HighProtein,
    LowCarb
}
