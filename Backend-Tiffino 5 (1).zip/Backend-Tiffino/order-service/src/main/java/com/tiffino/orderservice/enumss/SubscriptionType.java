package com.tiffino.orderservice.enumss;

public enum SubscriptionType {

    DAILY,
    WEEKLY,
    MONTHLY,
    YEARLY
}
