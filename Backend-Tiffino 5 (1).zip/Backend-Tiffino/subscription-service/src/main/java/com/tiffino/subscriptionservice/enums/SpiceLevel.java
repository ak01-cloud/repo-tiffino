package com.tiffino.subscriptionservice.enums;

public enum SpiceLevel {
    EXTRA_SPICY,
    MEDIUM,
    MILD,
    SPICY

}