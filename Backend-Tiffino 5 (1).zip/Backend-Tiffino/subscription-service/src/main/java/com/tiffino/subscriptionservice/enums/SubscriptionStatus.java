package com.tiffino.subscriptionservice.enums;

public enum SubscriptionStatus {
    ACTIVE, PAUSED, CANCELLED, EXPIRED;
}