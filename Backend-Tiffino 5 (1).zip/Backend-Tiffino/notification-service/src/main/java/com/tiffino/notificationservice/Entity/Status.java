package com.tiffino.notificationservice.Entity;

public enum Status {
    SENT,
    FAILED,
    PENDING,
    UPDATE,
    SKIPPED
}
