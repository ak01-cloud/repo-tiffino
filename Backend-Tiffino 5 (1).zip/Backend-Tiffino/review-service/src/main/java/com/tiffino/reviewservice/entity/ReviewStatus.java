package com.tiffino.reviewservice.entity;

public enum ReviewStatus {
    PENDING,
    APPROVED,
    REJECTED,
    DELETED,
    UPDATED

}