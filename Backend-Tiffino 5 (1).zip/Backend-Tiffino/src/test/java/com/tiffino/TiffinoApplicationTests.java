package com.tiffino;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TiffinoApplicationTests {

    @Test
    void contextLoads() {
    }

}
